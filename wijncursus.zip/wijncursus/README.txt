Uitgebreide Rode Wijncursus – Snelstart

1. Kopieer/plak index.html, style.css, script.js in een map.
2. Upload alle bestanden naar je Github repository (via 'Add File', 'Upload files').
3. Activeer Github Pages (Settings > Pages > Branch: main, Folder: /root).
4. Je site werkt binnen 1 minuut op https://jouw-gebruikersnaam.github.io/jouw-reponame/
5. Vul de cursus aan en commit nieuwe content simpel via Github-interface!

Tip: Voeg plaatjes toe in een /images folder.
