// Toekomstig uit te breiden met quiz, wizard, interactiviteit
console.log('Interne script voor wijncursus geladen.');
